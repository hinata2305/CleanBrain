%Copyright © 2022 Koten and Schüppen All rights reserved
%Important Notice: This code is not intended for medical applications 
%and does not have legal approval for such use. We strongly recommend 
%using FDA-approved software for any medical purposes. 

% Specify the installation path for the PLOS_DATA_CODE folder.
% Windows convention: current = 'my path\PLOS_DATA_CODE\' where backslashes are used as path separators.
% Linux convention: current = 'my path/PLOS_DATA_CODE/' where forward slashes are utilized as path separators.
current = '/data/backup/Graz/FWF/SG_FILTER/PLOS_DATA_CODE/';
addpath([current 'Code'], [current 'Simulate'])  % Add the Code and Simulate directories to the MATLAB path.

% Length of the simulated time course, defined as the number of time points.
timeL = 487;

% Parameters of the Gaussian filter for temporal smoothing of the data.
G{1}.RT = 1.24;                    % Repetition Time (TR) in seconds.
G{1}.LChoice = 'Gaussian';         % Choice of low-pass filter: Gaussian, in this case.
G{1}.LParam = 2.48;                % Standard cutoff frequency for the low-pass filter.
G{1}.HChoice = 'none';             % High-pass filter choice, not used.

G{1}.row = 1:(timeL);              % Define the row indices corresponding to the simulated time course.

% Initialize the filter using the specified parameters.
gK = spm_filter('set', G);

% Define the parameters for the Savitzky-Golay (SG) filter.
span4 = 15;                        % Polynomial span: number of points used to fit the polynomial.
order4 = 8;                        % Order of the polynomial for the SG filter.

% Number of simulations per iteration for statistical reliability assessment.
samp = 1000000;

% Specify the number of simulation iterations to perform.
sim = 100;

% Pre-allocate matrices for computational efficiency, initialized with NaNs to store results.
rel_Auto = nan(sim, samp);         % Matrix to hold reliability of autocorrelation for unfiltered time courses.
rel_Auto_filt = nan(sim, samp);    % Matrix to hold reliability of autocorrelation for filtered time courses.
obsAuto1 = nan(sim, samp);         % Matrix to store observed autocorrelation for first simulated time course.
obsAuto2 = nan(sim, samp);         % Matrix to store observed autocorrelation for second simulated time course.
obsAutoFilt1 = nan(sim, samp);     % Matrix to store observed autocorrelation for filtered first time course.
obsAutoFilt2 = nan(sim, samp);     % Matrix to store observed autocorrelation for filtered second time course.

% Additional matrices for Gaussian-filtered data.
obsAutoFiltGauss1 = nan(sim, samp);
obsAutoFiltGauss2 = nan(sim, samp);
rel_Auto_filtGauss = nan(sim, samp);  % Matrix to hold reliability for Gaussian-filtered time courses.

% Main loop iterating over samples.
for k = 1:samp
    
    parfor g = 1:sim  % Parallel loop for simulation runs, improving computational efficiency.
        
        % Define the target autocorrelation based on the current iteration.
        bb = 0.01 * g;

        % Simulate two autocorrelated time courses and calculate their observed autocorrelation.
        [timecour1Auto, obsAuto1(g, k)] = createAutoCor(0, bb, 1, timeL);
        [timecour2Auto, obsAuto2(g, k)] = createAutoCor(0, bb, 1, timeL);
        
        % Calculate the reliability (correlation) of the two simulated autocorrelated time courses.
        rel_Auto(g, k) = corr(timecour1Auto, timecour2Auto);
        
        % Apply detrending using the Savitzky-Golay filter to the simulated time courses.
        timecour1AutoFilt = detrend_gol_np(timecour1Auto, span4, order4, 1);
        timecour2AutoFilt = detrend_gol_np(timecour2Auto, span4, order4, 1);
        
        % Calculate the autocorrelation of the filtered time courses.
        obsAutoFilt1(g, k) = corr(timecour1AutoFilt(1:end-1), timecour1AutoFilt(2:end));
        obsAutoFilt2(g, k) = corr(timecour2AutoFilt(1:end-1), timecour2AutoFilt(2:end));
        
        % Calculate the reliability of the filtered time courses.
        rel_Auto_filt(g, k) = corr(timecour1AutoFilt, timecour2AutoFilt);
        
        % Apply the Gaussian filter to each of the simulated time courses.
        Clean_SPM_Gauss_p_1 = (spm_filter('apply', gK, timecour1Auto));
        Clean_SPM_Gauss_p_2 = (spm_filter('apply', gK, timecour2Auto));
       
        % Calculate the autocorrelation for the Gaussian-filtered time courses.
        obsAutoFiltGauss1(g, k) = corr(Clean_SPM_Gauss_p_1(1:end-1), Clean_SPM_Gauss_p_1(2:end));
        obsAutoFiltGauss2(g, k) = corr(Clean_SPM_Gauss_p_2(1:end-1), Clean_SPM_Gauss_p_2(2:end));
        
        % Calculate the reliability of the Gaussian-filtered time courses.
        rel_Auto_filtGauss(g, k) = corr(Clean_SPM_Gauss_p_1, Clean_SPM_Gauss_p_2);
    end
    
end

% Save results from simulations to a .mat file for later analysis.
save autosim.mat obsAuto1 obsAuto2 obsAutoFilt1 obsAutoFilt2 obsAutoFiltGauss1 obsAutoFiltGauss2 rel_Auto rel_Auto_filt rel_Auto_filtGauss

% Clear is commented out; uncommenting it would clear all variables from the workspace.
% clear

% Transpose reliability matrices for easier statistical analysis.
Ra = rel_Auto';
Raf = rel_Auto_filt';
Rag = rel_Auto_filtGauss';

% Calculate mean reliability across all simulations using Fisher's z-transformation for robustness.
MeanRa = tanh(mean(atanh(Ra)));   % Mean reliability for unfiltered time courses.
MeanRaf = tanh(mean(atanh(Raf))); % Mean reliability for filtered time courses.
MeanRag = tanh(mean(atanh(Rag))); % Mean reliability for Gaussian-filtered time courses.

% Calculate standard deviation of reliability distributions using Fisher's z-transformation.
StdRa = tanh(std(atanh(Ra)));     % Standard deviation for unfiltered time courses.
StdRaf = tanh(std(atanh(Raf)));   % Standard deviation for filtered time courses.
StdRag = tanh(std(atanh(Rag)));   % Standard deviation for Gaussian-filtered time courses.

% Calculate differences in standard deviations between filtered and unfiltered courses.
stdF_diff = tanh(std(atanh(Raf)) - std(atanh(Ra))); % Difference for filtered vs. unfiltered.
stdG_diff = tanh(std(atanh(Rag)) - std(atanh(Ra))); % Difference for Gaussian-filtered vs. unfiltered.

% Calculate mean autocorrelation for the simulated distributions.
Oa = tanh(mean((atanh(obsAuto1') + atanh(obsAuto2'))./2));   % Mean autocorrelation for unfiltered.
Oaf = tanh(mean((atanh(obsAutoFilt1') + atanh(obsAutoFilt2'))./2));   % Mean autocorrelation for filtered.
Oag = tanh(mean((atanh(obsAutoFiltGauss1') + atanh(obsAutoFiltGuass2'))./2)); % Mean autocorrelation for Gaussian-filtered.

% Plot the standard deviations for different conditions.
plot([StdRa; StdRaf; StdRag]')

% Plot the mean reliability for different conditions.
plot([MeanRa; MeanRaf; MeanRag]')

% Plot the mean autocorrelation for different conditions.
plot([Oa; Oaf; Oag]')

% Create a histogram of the reliability distributions at a specific sample index.
hist([Ra(:, 51), Raf(:, 51), Rag(:, 51)], 100)  % Histogram for comparison at sample 51 which is autocorr=0.51.

